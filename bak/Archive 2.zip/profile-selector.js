// ============================================================
// PROOFLY — Seletor de perfil multi-role (client / professional / establishment)
// ============================================================

const PROFILE_TYPES = {
  client: {
    role: 'cliente',
    icon: '👤',
    label: 'Cliente',
    subtitle: 'Buscar e avaliar profissionais',
    intent: 'cliente'
  },
  professional: {
    role: 'profissional',
    icon: '💼',
    label: 'Profissional',
    subtitle: 'Seu perfil profissional',
    intent: 'professional'
  },
  establishment: {
    role: 'estabelecimento',
    icon: '🏢',
    label: 'Estabelecimento',
    subtitle: 'Contratar profissionais para seu negócio',
    intent: 'establishment'
  }
};

const PROFILE_SELECTOR_URL = './selecionar-perfil.html';
const PROFILE_FORCE_PARAM = 'forceProfileSelect';

function normalizeProfileType(value) {
  if (!value) return null;
  if (typeof value === 'string') {
    return PROFILE_TYPES[value] ? value : null;
  }
  if (typeof value === 'object' && value.type) {
    const map = {
      client: 'client',
      cliente: 'client',
      professional: 'professional',
      profissional: 'professional',
      establishment: 'establishment',
      estabelecimento: 'establishment'
    };
    return map[value.type] || null;
  }
  return null;
}

/** Só conta escolha explícita do usuário — role do banco NÃO pula o seletor */
function getActiveProfileType(session) {
  const s = session || (typeof getSession === 'function' ? getSession() : null);
  return normalizeProfileType(s?.activeProfile);
}

function hasExplicitActiveProfile(session) {
  return !!getActiveProfileType(session);
}

function setActiveProfileType(type) {
  const profileType = normalizeProfileType(type);
  if (!profileType) return;
  const meta = PROFILE_TYPES[profileType];
  const session = (typeof getSession === 'function' ? getSession() : null) || {};
  session.activeProfile = profileType;
  session.role = meta.role;
  if (typeof setSession === 'function') setSession(session);
}

function getProfileHomeUrl(type, session) {
  const profileType = normalizeProfileType(type);
  const s = session || (typeof getSession === 'function' ? getSession() : null) || {};
  if (!profileType) return PROFILE_SELECTOR_URL;

  switch (profileType) {
    case 'client':
      return (typeof getClientId === 'function' ? getClientId(s) : s.clientId)
        ? './cliente.html'
        : './selecionar-cliente.html';
    case 'professional':
      return s.professionalId ? './dashboard-profissional.html' : './selecionar-profissional.html';
    case 'establishment':
      return s.establishmentId ? './contratar.html' : './selecionar-estabelecimento.html';
    default:
      return PROFILE_SELECTOR_URL;
  }
}

function redirectToActiveProfileHome(session) {
  const s = session || (typeof getSession === 'function' ? getSession() : null);
  const type = getActiveProfileType(s);
  if (!type) return false;
  window.location.href = getProfileHomeUrl(type, s);
  return true;
}

function isForceProfileSelect() {
  return new URLSearchParams(window.location.search).get(PROFILE_FORCE_PARAM) === 'true';
}

function getProfileSelectorUrl(force) {
  return force ? `${PROFILE_SELECTOR_URL}?${PROFILE_FORCE_PARAM}=true` : PROFILE_SELECTOR_URL;
}

function shouldShowProfileSelector(session) {
  const s = session || (typeof getSession === 'function' ? getSession() : null);
  if (!s?.userId) return true;
  if (isForceProfileSelect()) return true;
  return !getActiveProfileType(s);
}

function enforceProfileGuard(requiredType) {
  const profileType = normalizeProfileType(requiredType);
  if (!profileType) return true;

  const session = typeof getSession === 'function' ? getSession() : null;
  if (!session?.userId) {
    window.location.href = `./login.html?returnTo=${encodeURIComponent(window.location.pathname.split('/').pop() + window.location.search)}`;
    return false;
  }

  const current = getActiveProfileType(session);
  if (current === profileType) return true;

  if (current) {
    window.location.href = getProfileHomeUrl(current, session);
  } else {
    window.location.href = './cliente.html';
  }
  return false;
}

function selectProfileAndGo(type) {
  setActiveProfileType(type);
  const session = typeof getSession === 'function' ? getSession() : null;
  window.location.href = getProfileHomeUrl(type, session);
}

/** Monta opções do seletor pós-login (owner / prof / cliente ou genérico) */
function buildProfileEntryOptions(affiliations) {
  const aff = affiliations || {};
  const linked = [];
  const generic = [];

  const ownedEstablishments = aff.establishments?.length
    ? aff.establishments
    : (aff.establishment?.id ? [aff.establishment] : []);

  ownedEstablishments.forEach((est) => {
    linked.push({
      type: 'establishment',
      icon: '🏢',
      title: est.name,
      subtitle: `Contratar talentos · ${est.city || est.type || 'Estabelecimento'}`,
      badge: 'Owner',
      badgeRole: 'owner',
      entityId: est.id,
      entityName: est.name,
      linked: true
    });
  });

  if (aff.professional?.id) {
    const prof = aff.professional;
    const extra = prof.specialty || prof.current_establishment?.name || 'Profissional';
    linked.push({
      type: 'professional',
      icon: '💼',
      title: prof.name,
      subtitle: `Perfil profissional vinculado · ${extra}`,
      badge: 'Profissional',
      badgeRole: 'professional',
      entityId: prof.id,
      entityName: prof.name,
      linked: true
    });
  }
  if (aff.client?.id) {
    const cli = aff.client;
    linked.push({
      type: 'client',
      icon: '👤',
      title: cli.name,
      subtitle: `Buscar e avaliar · ${cli.city || 'área cliente'}`,
      badge: 'Cliente',
      badgeRole: 'client',
      entityId: cli.id,
      entityName: cli.name,
      linked: true
    });
  }

  if (linked.length) {
    linked.push({
      type: 'client',
      icon: '🔍',
      title: 'Só explorar',
      subtitle: 'Buscar sem escolher área agora',
      linked: false,
      browseOnly: true
    });
    return linked;
  }

  generic.push(
    {
      type: 'professional',
      icon: '💼',
      title: PROFILE_TYPES.professional.label,
      subtitle: 'Cadastrar ou vincular seu perfil profissional',
      linked: false
    },
    {
      type: 'establishment',
      icon: '🏢',
      title: PROFILE_TYPES.establishment.label,
      subtitle: 'Cadastrar ou vincular seu estabelecimento',
      linked: false
    },
    {
      type: 'client',
      icon: '👤',
      title: PROFILE_TYPES.client.label,
      subtitle: PROFILE_TYPES.client.subtitle,
      linked: false
    }
  );
  return generic;
}

function applyAffiliationToSession(type, entityId, entityName) {
  const profileType = normalizeProfileType(type);
  if (!profileType) return null;
  const meta = PROFILE_TYPES[profileType];
  const session = (typeof getSession === 'function' ? getSession() : null) || {};
  session.activeProfile = profileType;
  session.role = meta.role;
  if (profileType === 'professional' && entityId) {
    session.professionalId = entityId;
    if (entityName) session.professionalName = entityName;
  }
  if (profileType === 'establishment' && entityId) {
    session.establishmentId = entityId;
    if (entityName) session.establishmentName = entityName;
  }
  if (profileType === 'client' && entityId) {
    session.clientId = entityId;
  }
  if (typeof setSession === 'function') setSession(session);
  return session;
}

function selectAffiliationAndGo(option) {
  if (!option) return;
  if (option.browseOnly) {
    const session = (typeof getSession === 'function' ? getSession() : null) || {};
    delete session.activeProfile;
    if (typeof setSession === 'function') setSession(session);
    window.location.href = './cliente.html';
    return;
  }
  if (option.linked && option.entityId) {
    const session = applyAffiliationToSession(option.type, option.entityId, option.entityName);
    window.location.href = getProfileHomeUrl(option.type, session);
    return;
  }
  selectProfileAndGo(option.type);
}

function routeAfterLogin(intent) {
  const onboardingIntents = ['onboarding-profissional', 'onboarding-estabelecimento'];
  if (onboardingIntents.includes(intent)) {
    return `./${intent}.html?force=true`;
  }
  const profileIntent = profileTypeFromIntent(intent);
  if (profileIntent) {
    setActiveProfileType(profileIntent);
    return getProfileHomeUrl(profileIntent, typeof getSession === 'function' ? getSession() : null);
  }
  const params = new URLSearchParams(window.location.search);
  const rawReturn = params.get('returnTo');
  if (rawReturn) {
    try {
      const decoded = decodeURIComponent(rawReturn);
      if (!/^https?:\/\//i.test(decoded) && !decoded.includes('//')) {
        return decoded.startsWith('./') || decoded.startsWith('/')
          ? decoded
          : './' + decoded;
      }
    } catch { /* ignore */ }
  }
  const session = typeof getSession === 'function' ? getSession() : null;
  if (hasExplicitActiveProfile(session)) {
    return getProfileHomeUrl(getActiveProfileType(session), session);
  }
  return getProfileSelectorUrl();
}

function profileTypeFromIntent(intent) {
  const map = {
    cliente: 'client',
    client: 'client',
    professional: 'professional',
    profissional: 'professional',
    establishment: 'establishment',
    estabelecimento: 'establishment'
  };
  return map[intent] || null;
}

window.PROFILE_TYPES = PROFILE_TYPES;
window.PROFILE_SELECTOR_URL = PROFILE_SELECTOR_URL;
window.PROFILE_FORCE_PARAM = PROFILE_FORCE_PARAM;
window.normalizeProfileType = normalizeProfileType;
window.getActiveProfileType = getActiveProfileType;
window.hasExplicitActiveProfile = hasExplicitActiveProfile;
window.setActiveProfileType = setActiveProfileType;
window.getProfileHomeUrl = getProfileHomeUrl;
window.redirectToActiveProfileHome = redirectToActiveProfileHome;
window.isForceProfileSelect = isForceProfileSelect;
window.getProfileSelectorUrl = getProfileSelectorUrl;
window.shouldShowProfileSelector = shouldShowProfileSelector;
window.enforceProfileGuard = enforceProfileGuard;
window.selectProfileAndGo = selectProfileAndGo;
window.buildProfileEntryOptions = buildProfileEntryOptions;
window.applyAffiliationToSession = applyAffiliationToSession;
window.selectAffiliationAndGo = selectAffiliationAndGo;
window.routeAfterLogin = routeAfterLogin;
window.profileTypeFromIntent = profileTypeFromIntent;