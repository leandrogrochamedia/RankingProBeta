// =====================================================
// Ranking Pro — Configuração Global
// =====================================================

const APP_NAME = 'Ranking Pro';
const APP_ICON = '🏆';
const APP_SCORE_LABEL = 'Ranking Pro Score';

const SUPABASE_URL = "https://pyywdhjstvhmarvzijji.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5eXdkaGpzdHZobWFydnppamppIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEzODE4NTEsImV4cCI6MjA5Njk1Nzg1MX0.uLu4Xhazrrrmf9MCp7BzZFUYLBR1J8QHQmqp0f3E1Yg";

const DEBUG_MODE = true;
const PROOFLY_DEV_MENU = true;
const LIMITE_PAGINA = 10;

window.APP_NAME = APP_NAME;
window.APP_ICON = APP_ICON;
window.APP_SCORE_LABEL = APP_SCORE_LABEL;
window.DEBUG_MODE = DEBUG_MODE;
window.PROOFLY_DEV_MENU = PROOFLY_DEV_MENU;